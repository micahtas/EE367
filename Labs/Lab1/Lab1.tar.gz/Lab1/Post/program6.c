main()
{
printf("I'm in the parent directory of Room100A\n");
}

